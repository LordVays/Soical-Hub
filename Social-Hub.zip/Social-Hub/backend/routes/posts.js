const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const User = require('../models/User');


router.post('/', async (req, res) => {

    try {
        const { desc, img } = req.body;

        const newPost = new Post({
            userId: req.user.id,
            desc,
            img
        });

        const savedPost = await newPost.save();
        res.status(201).json(savedPost);
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.get('/', async (req, res) => {

    try {
        const posts = await Post.find().populate('user', 'username profileAvatar');
        res.status(200).json(posts);
    }

    catch (err) {
        res.status(500).json(err);
    }

})

router.get('/:id', async (req, res) => {

    try {
        const post = await Post.findById(req.params.id).populate('user', 'username profileAvatar');

        if (!post) return res.status(404).json('Публикация не найдена');

        res.status(200).json(post);
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.put('/:id', async (req, res) => {

    try {
        const post = await Post.findById(req.params.id);

        if (!post) return res.status(404).json('Публикация не найдена');

        if (post.user !== req.user.id) {
            return res.status(403).json('Вы можете обновлять только свои публикации');
        }

        const updatePost = await Post.findByIdAndUpdate(
            req.params.id,
            { $set: req.body },
            { new: true }
        );

        res.status(200).json(updatePost);
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.delete('/:id', async (req, res) => {

    try {
        const post = await Post.findById(req.params.id);

        if (!post) return res.status(404).json('Публикация не найдена');

        if (post.user !== req.user.id && !req.user.isAdmin) {
            return res.status(403).json('Вы можете удалить только свои публикации');
        }

        await Post.findByIdAndDelete(req.params.id);

        res.status(200).json('Публикация была удалена');
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.put('/:id/like', async (req, res) => {

    try {
        const post = await  Post.findById(req.params.id);

        if (!post) return res.status(404).json('Публикация не найдена');

        if (!post.likes.includes(req.user.id)) {
            await post.updateOne({ $push: { likes: req.user.id } });
            res.status(200).json('Публикация понравилась')
        }

        else {
            await post.updateOne({ $pull: { likes: req.user.id } });
            res.status(200).json('Публикация непонравилась');
        }
    }

    catch (err) {
        res.status(500).json(err);
    }

});

module.exports = router;