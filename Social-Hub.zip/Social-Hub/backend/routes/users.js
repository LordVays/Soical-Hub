const express = require('express');
const router = express.Router();
const User = require('../models/User');


router.get('/', async (req, res) => {

    try {
        if (!req.user.isAdmin) {
            return res.status(403).json('Only admin can get all users');
        }

        const users = await User.find().select('-password');

        res.status(200).json(users);
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.get('/:id', async (req, res) => {

    try {
        const user = await User.findById(req.params.id).select('-password');

        if (!user) return res.status(404).json('User not found');

        res.status(200).json(user);
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.put('/:id', async (req, res) => {

    try {
        if (req.params.id !== req.user.id && !req.user.isAdmin) {
            return res.status(403).json('You can update only your own profile');
        }

        if (req.body.password) {
            req.body.password = await bcrypt.hash(req.body.password, 12);
        }

        const updatedUser = await User.findByIdAndUpdate(
            req.params.id,
            { $set: req.body },
            { new: true }
        ).select('-password');

        res.status(200).json(updatedUser);
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.delete('/:id',async (req, res) => {

    try {
        if (req.params.id !== req.user.id && !req.user.isAdmin) {
            return res.status(403).json('You can delete only your own profile');
        }

        await User.findByIdAndDelete(req.params.id);

        res.status(200).json('User has been deleted');
    }

    catch (err) {
        res.status(500).json(err);
    }

});

router.put('/:id/follow', async (req, res) => {

    try {
        if (req.params.id === req.user.id) {
            return res.status(403).json('You cannot follow yourself');
        }

        const userToFollow = await User.findById(req.params.id);
        const currentUser = await User.findById(req.user.id);

        if (!userToFollow.followers.includes(req.user.id)) {
            await userToFollow.updateOne({ $push: { followers: req.user.id } });
            await currentUser.updateOne({ $push: { followings: req.params.id } });

            res.status(200).json('User has been followed');
        }

        else {
            await userToFollow.updateOne({ $pull: { followers: req.user.id } });
            await currentUser.updateOne({ $pull: { followings: req.params.id } });

            res.status(200).json('User has been unfollowed');
        }
    }

    catch (err) {
        res.status(500).json(err);
    }

});

module.exports = router;