const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({

    user: {
        type: String,
        required: true
    },

    desc: {
        type: String,
        default: ''
    },

    img: {
        date: Buffer,
        contentType: String,
        default: ''
    },

    likes: {
        type: Array,
        default: []
    },

    comments: [
        {
            user: String,
            text: String,
            createdAt: {
                type: Date,
                default: Date.now
            }
        }
    ]

}, { timestamps: true });

module.exports = mongoose.model('Post', PostSchema);