const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({

    username: {
        type: String,
        required: true,
        unique: true,
        minlength: 3,
        maxlength: 20
    },

    surname: {
        type: String,
        required: true
    },

    name: {
        type: String,
        required: true
    },

    lastname: {
        type: String,
        required: true
    },

    age: {
        type: Number,
        required: true,
        min: 1
    },

    email: {
        type: String,
        required: true,
        unique: true
    },

    password: {
        type: String,
        required: true,
        minlength: 6
    },

    profileAvatar: {
        data: Buffer,
        contentType: String,
        default: ''
    },

    profileCover: {
        data: Buffer,
        contentType: String,
        default: ''
    },

    city: {
        type: String,
        default: ''
    }

}, { timestamps: true });

module.exports = mongoose.model('User', UserSchema);